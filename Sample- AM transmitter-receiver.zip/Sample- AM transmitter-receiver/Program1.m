
clc
clear all
close all;
                           %AM TRANSMITTER %
                           
                       %Modulating Signal Generation 
A=5;                                      
fa=50;                                     
T=1/fa;                                    
t=0:T/1000:2*T;                            
ya=A*sin(2*pi*fa*t);                      
figure(1);
subplot(3,1,1);
plot(t,ya);                 
title ( 'Modulating Signal');
xlabel ( 'time(second)')
ylabel ('Amplitud(volt)');
 
 
 
%                Carrrier Signal Generation 
A=5;                                         
fc=2000;                                      
yc=A*sin(2*pi*fc*t);                         
figure(1);
subplot(3,1,2);
plot(t,yc);                   
title ( 'Carrier  Signal'  );
xlabel ( 'time(second)');
ylabel ('Amplitud(volt)');
 
 
 
%            AM modulated Signal Generation 
 
ym=(A+ ya).*sin(2*pi*fc*t);
figure(1)
subplot(3,1,3)
plot(t,ym)            
title ( 'AM modulated  Signal'  );
xlabel ( 'time(second)');
ylabel ('Amplitud(volt)');
 
 
                          %AM RECEIVER%
 
                          %Recived signal     
ym=(A+ ya).*sin(2*pi*fc*t);   
figure(2)
subplot(4,1,1)
plot(t,ym)            
title ( 'Received Signal'  );
xlabel ( 'time(second) ');
ylabel ('Amplitud(volt)');
 
 
 
%                Carrrier Signal Generation 
A=5;                                         
fc=2000;                                    
yc=A*sin(2*pi*fc*t);                         
figure(2)
subplot(4,1,2);
plot(t,yc);                                   
title ( 'Carrier  Signal'  );
xlabel ( 'time(second)');
ylabel (' Amplitud(volt)   ');
 
 
 
%               Multiply Carrrier Signal with Received Signal
ymm=ym.*sin(2*pi*fc*t);  
figure(2)
subplot(4,1,3);
plot(t,ymm);
title(' Received signal after Multiplication of Carrrier Signal ');
xlabel ( 'time(second)');
ylabel (' Amplitud(volt)   ');
 
 
 
                %Filtering to Findout Modulating Signal 
wc=200/50000;                     
[a,b]=butter(2,wc,'low');          
sig=filter(a,b,ymm);              
figure(2)
subplot(4,1,4); 
plot(t,2*sig -5);
title ('AM Demodulated signal');
xlabel ( 'time(second) ');
ylabel (' Amplitud(volt)   ');
 
 


